echo "ĐÂY CHỈ LÀ FILE THAY THẾ CHO FILE start.sh ĐÃ BỊ HỎNG!"

CHECKBIT=$(arch)

if [ "$CHECKBIT" == "arm64" ]; then
	echo "Detected 64bit iDevice!"
	sudo sh /var/64bit.sh
elif [ "$CHECKBIT" == "arm" ] || [ "$CHECKBIT" == "armv7" ]; then
	echo "Detected 32bit iDevice!"
	sudo sh /var/32bit.sh
else
	echo "Can not detect the kernel!"
	sudo sh /var/kernel.sh
fi